﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using DigitalMusicApp.DataAccess.Models;
using DigitalMusicApp.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace DigitalMusicApp.Controllers
{
    public class PlayerController : Controller
    {
        private readonly AudioContext _context;
        public PlayerController(AudioContext context)
        {
            _context = context;
        }

        // GET: Player
        public IActionResult Index(string searchString)
        {
            var audios = from m in _context.Audio
                         select m;

            var filteredAudios = audios.ToList();

            if (!String.IsNullOrEmpty(searchString))
            {
                filteredAudios = filteredAudios.Where(s => s.Title.ToUpper().Contains(searchString.ToUpper()) || s.Composer.ToUpper().Contains(searchString.ToUpper())).ToList();
                 //filteredAudios = filteredAudios.Where(x => filteredAudios.Any(x => x.ToUpperInvariant().Contains(searchString.ToUpperInvariant())));
            }

            return View(filteredAudios.ToList());

            //var albums = _context.Audio.ToList();
            //return View(albums);
        }


        public async Task<IActionResult> Details(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var audioModel = await _context.Audio
                .FirstOrDefaultAsync(m => m.Id == id);
            if (audioModel == null)
            {
                return NotFound();
            }

            return View(audioModel);
        }


    }
}