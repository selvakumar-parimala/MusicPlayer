﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using DigitalMusicApp.DataAccess.Models;
using DigitalMusicApp.Models;
using DigitalMusicApp.Business;

namespace DigitalMusicApp.Controllers
{
    public class AudioController : Controller
    {
        private readonly AudioContext _context;

        public AudioController(AudioContext context)
        {
            _context = context;
        }

        // GET: Audio
        public IActionResult Index()
        {

           // return View(await _context.Albums.ToListAsync());
            var albums = _context.Audio.ToList();
            return View(albums);
        }

        // GET: Audio/Details/5
        public async Task<IActionResult> Details(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var audioModel = await _context.Audio
                .FirstOrDefaultAsync(m => m.Id == id);
            if (audioModel == null)
            {
                return NotFound();
            }

            return View(audioModel);
        }

        // GET: Audio/Create
        public IActionResult Create()
        {
            return View();
        }

        // POST: Audio/Create
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("Id,Album,Title,Composer,ArtistName,ReleaseDate,FilePath")] AudioModel audioModel)
        {
            if (ModelState.IsValid)
            {
                _context.Add(audioModel);
                await _context.SaveChangesAsync();
                return RedirectToAction(nameof(Index));
            }
            return View(audioModel);
        }

        // GET: Audio/Edit/5
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var audioModel = await _context.Audio.FindAsync(id);
            if (audioModel == null)
            {
                return NotFound();
            }
            return View(audioModel);
        }

        // POST: Audio/Edit/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, [Bind("Id,Album,Title,Composer,ArtistName,ReleaseDate,FilePath")] AudioModel audioModel)
        {
            if (id != audioModel.Id)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    _context.Update(audioModel);
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!AudioModelExists(audioModel.Id))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction(nameof(Index));
            }
            return View(audioModel);
        }

        // GET: Audio/Delete/5
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var audioModel = await _context.Audio
                .FirstOrDefaultAsync(m => m.Id == id);
            if (audioModel == null)
            {
                return NotFound();
            }

            return View(audioModel);
        }

        // POST: Audio/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var audioModel = await _context.Audio.FindAsync(id);
            _context.Audio.Remove(audioModel);
            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

        private bool AudioModelExists(int id)
        {
            return _context.Audio.Any(e => e.Id == id);
        }
    }
}
