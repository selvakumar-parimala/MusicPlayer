﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace DigitalMusicApp.DataAccess.Models
{
    public class AudioModel
    {
        public int Id { set; get; }
        public int AlbumId { set; get; }
        public string Title { set; get; }
        public string Composer { set; get; }
        public string ArtistName { set; get; }
        public DateTime ReleaseDate { set; get; }
        public string FilePath { set; get; }
    }
}
