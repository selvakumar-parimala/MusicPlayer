﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace DigitalMusicApp.DataAccess.Models
{
    public class AlbumModel
    {
        public int Id { set; get; }
        public string AlbumName { set; get; }

        [DataType(DataType.Date), DisplayFormat(DataFormatString = "{0:dd/MM/yy}", ApplyFormatInEditMode = true)]
        public DateTime ReleasedDate { set; get; }
        public int ComposerId { set; get; }


    }
}
