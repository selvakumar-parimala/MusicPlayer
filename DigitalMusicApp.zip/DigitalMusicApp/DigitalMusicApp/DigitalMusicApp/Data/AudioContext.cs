﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using DigitalMusicApp.DataAccess.Models;

namespace DigitalMusicApp.Models
{
    public class AudioContext : DbContext
    {
        public AudioContext (DbContextOptions<AudioContext> options)
            : base(options)
        {
            
        }

        public DbSet<AudioModel> Audio { get; set; }
        public DbSet<AlbumModel> Albums { get; set; }
        public DbSet<ComposerModel> Composers { get; set; }
    }
}
