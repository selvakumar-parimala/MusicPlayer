﻿using DigitalMusicApp.DataAccess.Models;
using DigitalMusicApp.Models;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.DependencyInjection;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace DigitalMusicApp.Business
{
    public class AlbumCreation
    {
        public static void Initialize(IServiceProvider serviceProvider)
        {
            using (var context = new AudioContext(
                serviceProvider.GetRequiredService<DbContextOptions<AudioContext>>()))
            {
                // Look for any board games.
                if (context.Audio.Any())
                {
                    return;   // Data was already seeded
                }
                AlbumModel album = new AlbumModel() {AlbumName  = "Music 1", ComposerId=1, ReleasedDate= new DateTime(2019, 3, 1) };
                context.Albums.AddRange(album);
                album = new AlbumModel() { AlbumName = "Music 2", ComposerId = 2, ReleasedDate = new DateTime(2019, 6, 12) };
                context.Albums.AddRange(album);
                context.SaveChanges();

                AudioModel audio = new AudioModel() { Title = "AA", AlbumId = 1, ArtistName = "XXX", Composer = "C1", FilePath = "music1.mp3" };
                context.Audio.AddRange(audio);
                audio = new AudioModel() {  Title = "BB", AlbumId = 2, ArtistName = "YYY", Composer = "C2", FilePath = "music2.mp3" };
                context.Audio.Add(audio);
                context.SaveChanges();

                ComposerModel composer = new ComposerModel() { FirstName = "c1", LastName = "c2" };
                context.Composers.AddRange(composer);
                composer = new ComposerModel() { FirstName = "d1", LastName = "d2" };
                context.Composers.AddRange(composer);
                context.SaveChanges();
            }
        }
    }
}
